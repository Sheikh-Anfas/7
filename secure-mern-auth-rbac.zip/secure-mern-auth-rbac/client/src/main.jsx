import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const API = import.meta.env.VITE_API_URL ?? "http://localhost:4000/api";

async function api(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(options.headers ?? {}) },
    ...options,
  });

  if (response.status === 204) return null;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error ?? "Request failed");
  return data;
}

function App() {
  const [user, setUser] = useState(null);
  const [notes, setNotes] = useState([]);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [error, setError] = useState("");
  const [mode, setMode] = useState("login");

  useEffect(() => {
    api("/auth/me")
      .then(({ user }) => {
        setUser(user);
        return api("/notes");
      })
      .then((data) => data && setNotes(data.notes))
      .catch(() => {});
  }, []);

  async function submitAuth(event) {
    event.preventDefault();
    setError("");
    try {
      const data = await api(`/auth/${mode}`, {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      setUser(data.user);
      if (mode === "login") setNotes((await api("/notes")).notes);
    } catch (e) {
      setError(e.message);
    }
  }

  async function createNote(event) {
    event.preventDefault();
    setError("");
    try {
      const { note } = await api("/notes", {
        method: "POST",
        body: JSON.stringify({ title, body }),
      });
      setNotes((current) => [note, ...current]);
      setTitle("");
      setBody("");
    } catch (e) {
      setError(e.message);
    }
  }

  async function logout() {
    await api("/auth/logout", { method: "POST" }).catch(() => {});
    setUser(null);
    setNotes([]);
  }

  if (!user) {
    return (
      <main className="shell">
        <section className="card">
          <h1>Secure MERN Auth</h1>
          <p className="muted">Session cookies · RBAC · ownership checks · rate limits</p>
          <form onSubmit={submitAuth}>
            <label>Email<input type="email" value={email} onChange={e => setEmail(e.target.value)} required /></label>
            <label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={mode === "register" ? 12 : 1} /></label>
            <button>{mode === "login" ? "Log in" : "Create account"}</button>
          </form>
          <button className="link" onClick={() => setMode(mode === "login" ? "register" : "login")}>
            {mode === "login" ? "Need an account?" : "Already have an account?"}
          </button>
          {error && <p className="error">{error}</p>}
        </section>
      </main>
    );
  }

  return (
    <main className="shell">
      <section className="card">
        <div className="row">
          <div>
            <h1>Your notes</h1>
            <p className="muted">{user.email} · role: {user.role}</p>
          </div>
          <button className="secondary" onClick={logout}>Log out</button>
        </div>

        <form onSubmit={createNote}>
          <label>Title<input value={title} onChange={e => setTitle(e.target.value)} required maxLength={120} /></label>
          <label>Note<textarea value={body} onChange={e => setBody(e.target.value)} maxLength={5000} /></label>
          <button>Add note</button>
        </form>

        {error && <p className="error">{error}</p>}

        <div className="notes">
          {notes.map(note => (
            <article className="note" key={note._id}>
              <strong>{note.title}</strong>
              <p>{note.body}</p>
            </article>
          ))}
          {!notes.length && <p className="muted">No notes yet.</p>}
        </div>
      </section>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
