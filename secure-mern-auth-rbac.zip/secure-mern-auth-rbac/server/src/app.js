import express from "express";
import cors from "cors";
import helmet from "helmet";
import { config } from "./config.js";
import { sessionMiddleware } from "./session.js";
import { apiLimiter, loginLimiter } from "./rateLimit.js";
import authRoutes from "./routes/auth.js";
import noteRoutes from "./routes/notes.js";
import adminRoutes from "./routes/admin.js";

export const app = express();

if (config.trustProxy) app.set("trust proxy", 1);

app.disable("x-powered-by");

app.use(helmet());
app.use(cors({
  origin: config.clientOrigin,
  credentials: true,
  methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type"],
}));
app.use(express.json({ limit: "16kb" }));
app.use(sessionMiddleware);
app.use(apiLimiter);

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.use("/api/auth/login", loginLimiter);
app.use("/api/auth", authRoutes);
app.use("/api/notes", noteRoutes);
app.use("/api/admin", adminRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});
