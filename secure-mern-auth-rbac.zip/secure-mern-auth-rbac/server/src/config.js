import "dotenv/config";

const required = (name) => {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
};

const nodeEnv = process.env.NODE_ENV ?? "development";

export const config = {
  env: nodeEnv,
  port: Number(process.env.PORT ?? 4000),
  mongoUri: required("MONGO_URI"),
  sessionSecret: required("SESSION_SECRET"),
  clientOrigin: required("CLIENT_ORIGIN"),
  cookieSecure: process.env.COOKIE_SECURE === "true" || nodeEnv === "production",
  trustProxy: process.env.TRUST_PROXY === "true",
};
