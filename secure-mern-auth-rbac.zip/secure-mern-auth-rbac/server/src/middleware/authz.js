/*
 * All permission decisions live here.
 *
 * The routes should ask this module "can this authenticated principal perform
 * this action?" rather than duplicating role/ownership checks throughout the app.
 *
 * Security model:
 * - user: can operate on resources they own.
 * - admin: can operate on any resource where an admin action is explicitly allowed.
 * - unknown roles/actions: deny.
 */
const permissions = {
  user: new Set([
    "notes:create",
    "notes:read:own",
    "notes:update:own",
    "notes:delete:own",
  ]),
  admin: new Set([
    "notes:create",
    "notes:read:own",
    "notes:update:own",
    "notes:delete:own",
    "notes:read:any",
    "users:read:any",
  ]),
};

export function can(user, action) {
  return Boolean(user && permissions[user.role]?.has(action));
}

export function requirePermission(action) {
  return (req, res, next) => {
    if (!can(req.user, action)) {
      return res.status(403).json({ error: "Forbidden" });
    }
    next();
  };
}

/*
 * Prefer the explicit helper below in request handlers. It avoids hidden
 * global state and makes the ownership decision obvious at the call site.
 */
export function ownsResource(user, ownerId) {
  return Boolean(user && ownerId && String(user._id) === String(ownerId));
}

export function canAccessOwnedResource(user, ownerId, adminAction = null) {
  if (ownsResource(user, ownerId)) return true;
  if (adminAction) return can(user, adminAction);
  return false;
}
