import rateLimit from "express-rate-limit";

const common = {
  standardHeaders: "draft-8",
  legacyHeaders: false,
};

export const apiLimiter = rateLimit({
  ...common,
  windowMs: 15 * 60 * 1000,
  limit: 300,
  message: { error: "Too many requests; try again later" },
});

export const loginLimiter = rateLimit({
  ...common,
  windowMs: 15 * 60 * 1000,
  limit: 10,
  skipSuccessfulRequests: true,
  message: { error: "Too many login attempts; try again later" },
});
