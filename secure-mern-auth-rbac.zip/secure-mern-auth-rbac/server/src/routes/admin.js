import { Router } from "express";
import { User } from "../models/User.js";
import { requireAuth } from "../middleware/auth.js";
import { requirePermission } from "../middleware/authz.js";

const router = Router();

router.get("/users", requireAuth, requirePermission("users:read:any"), async (req, res, next) => {
  try {
    const users = await User.find({}, { email: 1, role: 1, createdAt: 1 })
      .sort({ createdAt: -1 })
      .lean();

    res.json({
      users: users.map((user) => ({
        id: user._id.toString(),
        email: user.email,
        role: user.role,
        createdAt: user.createdAt,
      })),
    });
  } catch (error) {
    next(error);
  }
});

export default router;
