import { Router } from "express";
import bcrypt from "bcrypt";
import { User } from "../models/User.js";
import { validate } from "../middleware/validation.js";
import { registerSchema, loginSchema } from "../schemas.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

function publicUser(user) {
  return { id: user._id.toString(), email: user.email, role: user.role };
}

router.post("/register", validate(registerSchema), async (req, res, next) => {
  try {
    const { email, password } = req.validatedBody;

    const existing = await User.findOne({ email }).lean();
    if (existing) {
      // Generic response prevents reliable account enumeration.
      return res.status(400).json({ error: "Unable to create account" });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    // IMPORTANT: role is intentionally not read from req.body.
    const user = await User.create({ email, passwordHash, role: "user" });

    return res.status(201).json({ user: publicUser(user) });
  } catch (error) {
    if (error?.code === 11000) {
      return res.status(400).json({ error: "Unable to create account" });
    }
    next(error);
  }
});

router.post("/login", validate(loginSchema), async (req, res, next) => {
  try {
    const { email, password } = req.validatedBody;

    const user = await User.findOne({ email }).select("+passwordHash");
    const valid = user ? await bcrypt.compare(password, user.passwordHash) : false;

    // Same public response whether the account exists or not.
    if (!valid) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    // Regenerate the session ID after authentication to mitigate fixation.
    req.session.regenerate((err) => {
      if (err) return next(err);

      req.session.user = {
        _id: user._id.toString(),
        email: user.email,
        role: user.role,
      };

      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);
        res.json({ user: publicUser(user) });
      });
    });
  } catch (error) {
    next(error);
  }
});

router.post("/logout", requireAuth, (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie("sid");
    res.status(204).end();
  });
});

router.get("/me", requireAuth, async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id).lean();
    if (!user) {
      req.session.destroy(() => {});
      return res.status(401).json({ error: "Authentication required" });
    }
    res.json({ user: publicUser(user) });
  } catch (error) {
    next(error);
  }
});

export default router;
