import { Router } from "express";
import mongoose from "mongoose";
import { Note } from "../models/Note.js";
import { requireAuth } from "../middleware/auth.js";
import { requirePermission, canAccessOwnedResource } from "../middleware/authz.js";
import { validate } from "../middleware/validation.js";
import { noteSchema, noteIdSchema } from "../schemas.js";

const router = Router();

router.use(requireAuth);

router.post("/", requirePermission("notes:create"), validate(noteSchema), async (req, res, next) => {
  try {
    const note = await Note.create({
      // Never accept ownerId from the client.
      ownerId: req.user._id,
      ...req.validatedBody,
    });
    res.status(201).json({ note });
  } catch (error) {
    next(error);
  }
});

router.get("/", requirePermission("notes:read:own"), async (req, res, next) => {
  try {
    const notes = await Note.find({ ownerId: req.user._id }).sort({ createdAt: -1 }).lean();
    res.json({ notes });
  } catch (error) {
    next(error);
  }
});

router.get("/:id", validate(noteIdSchema), async (req, res, next) => {
  try {
    // Route params are validated explicitly; don't accept arbitrary Mongo queries.
    const parsedParams = noteIdSchema.safeParse(req.params);
    if (!parsedParams.success || !mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ error: "Invalid note id" });
    }

    const note = await Note.findById(req.params.id).lean();
    if (!note) return res.status(404).json({ error: "Not found" });

    if (!canAccessOwnedResource(req.user, note.ownerId, "notes:read:any")) {
      return res.status(403).json({ error: "Forbidden" });
    }

    res.json({ note });
  } catch (error) {
    next(error);
  }
});

router.patch("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ error: "Invalid note id" });
    }
    const parsed = noteSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid request" });

    const note = await Note.findById(req.params.id);
    if (!note) return res.status(404).json({ error: "Not found" });

    if (!canAccessOwnedResource(req.user, note.ownerId, "notes:read:any")) {
      return res.status(403).json({ error: "Forbidden" });
    }

    note.set(parsed.data);
    await note.save();
    res.json({ note });
  } catch (error) {
    next(error);
  }
});

router.delete("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ error: "Invalid note id" });
    }

    const note = await Note.findById(req.params.id).lean();
    if (!note) return res.status(404).json({ error: "Not found" });

    if (!canAccessOwnedResource(req.user, note.ownerId, "notes:read:any")) {
      return res.status(403).json({ error: "Forbidden" });
    }

    await Note.deleteOne({ _id: note._id });
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

export default router;
