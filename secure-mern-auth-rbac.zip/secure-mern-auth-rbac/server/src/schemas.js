import { z } from "zod";

const email = z.string().trim().toLowerCase().email().max(254);
const password = z.string().min(12).max(128);

export const registerSchema = z.object({
  email,
  password,
}).strict();

export const loginSchema = z.object({
  email,
  password: z.string().min(1).max(128),
}).strict();

export const noteSchema = z.object({
  title: z.string().trim().min(1).max(120),
  body: z.string().max(5000),
}).strict();

export const noteIdSchema = z.object({
  id: z.string().regex(/^[a-f\\d]{24}$/i, "Invalid note id"),
}).strict();
