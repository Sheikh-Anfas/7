import session from "express-session";
import MongoStore from "connect-mongo";
import { config } from "./config.js";

export const sessionMiddleware = session({
  name: "sid",
  secret: config.sessionSecret,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  store: MongoStore.create({
    mongoUrl: config.mongoUri,
    ttl: 60 * 60 * 8,
    touchAfter: 60,
  }),
  cookie: {
    httpOnly: true,
    secure: config.cookieSecure,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 8,
  },
});
