import test from "node:test";
import assert from "node:assert/strict";
import { can, ownsResource, canAccessOwnedResource } from "../src/middleware/authz.js";

const user = { _id: "u1", role: "user" };
const admin = { _id: "a1", role: "admin" };

test("normal user can read only owned resources", () => {
  assert.equal(ownsResource(user, "u1"), true);
  assert.equal(canAccessOwnedResource(user, "u1"), true);
  assert.equal(canAccessOwnedResource(user, "u2"), false);
});

test("admin can read any resource only when explicit permission is requested", () => {
  assert.equal(canAccessOwnedResource(admin, "u2", "notes:read:any"), true);
  assert.equal(canAccessOwnedResource(admin, "u2"), false);
});

test("unknown role/action is denied", () => {
  assert.equal(can({ _id: "x", role: "root" }, "users:read:any"), false);
  assert.equal(can(user, "users:read:any"), false);
});

test("client-controlled role does not create permissions", () => {
  const forged = { _id: "u1", role: "user", requestedRole: "admin" };
  assert.equal(can(forged, "users:read:any"), false);
});
